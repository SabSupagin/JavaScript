const findPerimeter = (length,width) => {
    return (length + width) * 2
}

console.log(findPerimeter(6, 7));
console.log(findPerimeter(20, 10));
console.log(findPerimeter(2, 9));